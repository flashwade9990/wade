# Customer Support Triage Agent

A runnable FastAPI project that demonstrates a multi-agent customer support ticket triage workflow.

It can:

- classify support tickets into product/support categories
- score urgency, sentiment, and customer impact
- decide priority and routing team
- retrieve relevant knowledge base articles
- generate an internal handoff summary and a customer reply draft
- store triage results in SQLite
- provide a simple browser UI and JSON API

The project is intentionally runnable without any paid LLM API key. The current implementation uses deterministic agent components, keyword scoring, lightweight retrieval, and templates so that it works immediately in local development and CI. You can later replace any agent class with an LLM-backed implementation.

## Architecture

```text
Ticket input
  -> IntentAgent          category classification
  -> UrgencyAgent         priority and SLA estimation
  -> SentimentAgent       sentiment and frustration signals
  -> KnowledgeAgent       KB retrieval
  -> RoutingAgent         owner team and escalation decision
  -> ResponseAgent        customer reply draft and internal summary
  -> SupervisorAgent      confidence and final packaged result
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open the web UI:

```text
http://127.0.0.1:8000
```

Open the interactive API docs:

```text
http://127.0.0.1:8000/docs
```

## Example API call

```bash
curl -X POST http://127.0.0.1:8000/api/triage \
  -H "Content-Type: application/json" \
  -d '{
    "subject": "Production API is returning 500 errors",
    "body": "All checkout requests are failing after the latest release. This is urgent and affects our enterprise customers.",
    "customer_tier": "enterprise",
    "channel": "email"
  }'
```

## Run tests

```bash
pytest -q
```

## Docker

```bash
docker compose up --build
```

Then open:

```text
http://127.0.0.1:8000
```

## API endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | service health check |
| POST | `/api/triage` | run the triage workflow |
| GET | `/api/tickets` | list stored triage results |
| GET | `/api/categories` | show supported categories |

## Project structure

```text
app/
  agent.py             multi-agent orchestration
  classifier.py        intent, urgency, and sentiment agents
  composer.py          reply and handoff generation
  config.py            settings
  kb.py                knowledge retrieval agent
  main.py              FastAPI app and endpoints
  schemas.py           API models
  storage.py           SQLite persistence
  sample_data/kb.json  starter knowledge base
  static/index.html    simple web UI
tests/
  test_agent.py        unit tests
.github/workflows/ci.yml
Dockerfile
docker-compose.yml
requirements.txt
```

## Customization ideas

1. Add company-specific categories in `app/classifier.py`.
2. Add real support playbooks in `app/sample_data/kb.json`.
3. Swap `ResponseAgent` for an LLM-backed implementation while keeping the same `TriageResult` schema.
4. Connect the `/api/triage` endpoint to Zendesk, Intercom, Freshdesk, Jira, Linear, or Slack webhooks.
5. Add human feedback into `storage.py` and use it to improve category confidence thresholds.

## GitHub upload

Unzip this folder, create a repository, then run:

```bash
git init
git add .
git commit -m "Initial customer support triage agent"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

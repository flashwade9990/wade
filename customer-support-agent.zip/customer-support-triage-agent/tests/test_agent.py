from app.agent import CustomerSupportTriageAgent
from app.schemas import TicketInput


def test_triage_outage_ticket_is_escalated():
    agent = CustomerSupportTriageAgent()
    result = agent.triage(TicketInput(
        subject="Production API is returning 500 errors",
        body="All checkout requests are failing. This is urgent and affects enterprise customers.",
        customer_tier="enterprise",
        channel="email",
    ))
    assert result.category == "bug_outage"
    assert result.priority in {"P0", "P1"}
    assert result.escalation_required is True
    assert result.assigned_team in {"Engineering On-call", "Engineering Incident Commander"}
    assert result.retrieved_articles


def test_triage_billing_ticket_routes_to_billing():
    agent = CustomerSupportTriageAgent()
    result = agent.triage(TicketInput(
        subject="Refund request for duplicate payment",
        body="We were charged twice on the same invoice and need a refund.",
        customer_tier="standard",
        channel="chat",
    ))
    assert result.category == "billing_refund"
    assert result.assigned_team == "Billing Operations"
    assert "refund" in result.customer_reply_draft.lower()


def test_triage_feature_request_is_not_urgent_by_default():
    agent = CustomerSupportTriageAgent()
    result = agent.triage(TicketInput(
        subject="Feature request: export report as CSV",
        body="It would be helpful to support CSV export in the dashboard. No rush.",
        customer_tier="free",
        channel="email",
    ))
    assert result.category == "feature_request"
    assert result.priority == "P3"
    assert result.escalation_required is False

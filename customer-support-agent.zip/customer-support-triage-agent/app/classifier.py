from dataclasses import dataclass
from typing import Dict, List, Tuple

from app.schemas import AgentTrace, Priority, Sentiment, TicketInput
from app.text_utils import clamp, contains_any, normalize, tokenize


@dataclass(frozen=True)
class CategoryDefinition:
    label: str
    team: str
    keywords: List[str]


CATEGORIES: Dict[str, CategoryDefinition] = {
    "login_access": CategoryDefinition(
        label="Login and access",
        team="Identity Support",
        keywords=[
            "login", "log in", "password", "reset password", "2fa", "mfa", "otp", "sso",
            "oauth", "account locked", "verification code", "cannot access", "sign in",
            "\u767b\u5f55", "\u5bc6\u7801", "\u9a8c\u8bc1\u7801", "\u65e0\u6cd5\u767b\u5f55",
        ],
    ),
    "billing_refund": CategoryDefinition(
        label="Billing and refunds",
        team="Billing Operations",
        keywords=[
            "invoice", "refund", "billing", "charged", "payment", "credit card", "receipt",
            "subscription", "plan", "tax", "coupon", "price", "quota",
            "\u53d1\u7968", "\u9000\u6b3e", "\u4ed8\u6b3e", "\u8ba2\u9605", "\u6263\u8d39", "\u4f59\u989d",
        ],
    ),
    "bug_outage": CategoryDefinition(
        label="Bug or outage",
        team="Engineering On-call",
        keywords=[
            "bug", "error", "500", "503", "crash", "broken", "down", "outage", "latency",
            "slow", "timeout", "failing", "incident", "production", "all users", "cannot use",
            "\u9519\u8bef", "\u6545\u969c", "\u5d29\u6e83", "\u5b95\u673a", "\u5ef6\u8fdf", "\u65e0\u6cd5\u4f7f\u7528",
        ],
    ),
    "security_privacy": CategoryDefinition(
        label="Security and privacy",
        team="Security Response",
        keywords=[
            "security", "privacy", "breach", "hacked", "phishing", "data leak", "unauthorized",
            "suspicious", "stolen", "token exposed", "credential", "gdpr", "delete data",
            "\u5b89\u5168", "\u6cc4\u9732", "\u9ed1\u5ba2", "\u9690\u79c1", "\u5220\u9664\u6570\u636e",
        ],
    ),
    "integration_api": CategoryDefinition(
        label="Integration and API",
        team="Developer Support",
        keywords=[
            "api", "sdk", "webhook", "integration", "endpoint", "rate limit", "token", "json",
            "payload", "auth header", "callback", "developer", "curl",
            "\u63a5\u53e3", "webhook", "\u96c6\u6210", "\u5f00\u53d1\u8005", "\u8c03\u7528", "\u9650\u6d41",
        ],
    ),
    "feature_request": CategoryDefinition(
        label="Feature request",
        team="Product Management",
        keywords=[
            "feature", "request", "enhancement", "roadmap", "suggest", "idea", "wish", "would like",
            "support for", "can you add", "proposal",
            "\u9700\u6c42", "\u5efa\u8bae", "\u5e0c\u671b", "\u529f\u80fd", "\u8def\u7ebf\u56fe",
        ],
    ),
    "how_to": CategoryDefinition(
        label="How-to question",
        team="Customer Success",
        keywords=[
            "how do i", "how to", "configure", "setup", "set up", "where can i", "guide", "tutorial",
            "documentation", "best practice", "help me", "steps",
            "\u5982\u4f55", "\u600e\u4e48", "\u914d\u7f6e", "\u6559\u7a0b", "\u6b65\u9aa4", "\u5e2e\u52a9",
        ],
    ),
}

URGENCY_TERMS = [
    "urgent", "asap", "immediately", "critical", "production", "all users", "blocked",
    "business down", "cannot pay", "data loss", "security breach", "vip", "enterprise",
    "\u7d27\u6025", "\u7acb\u523b", "\u751f\u4ea7\u73af\u5883", "\u5168\u90e8\u7528\u6237", "\u963b\u585e", "\u6570\u636e\u4e22\u5931",
]
LOW_URGENCY_TERMS = ["question", "minor", "whenever", "no rush", "suggestion", "\u4e0d\u7740\u6025", "\u5efa\u8bae"]
NEGATIVE_TERMS = [
    "angry", "frustrated", "disappointed", "terrible", "bad", "broken", "unacceptable",
    "cancel", "churn", "complaint", "escalate", "\u751f\u6c14", "\u5931\u671b", "\u6295\u8bc9", "\u7cdf\u7cd5", "\u53d6\u6d88",
]
POSITIVE_TERMS = ["thanks", "thank you", "great", "love", "helpful", "\u8c22\u8c22", "\u5f88\u597d", "\u559c\u6b22"]


class IntentAgent:
    def classify(self, ticket: TicketInput) -> Tuple[str, float, AgentTrace]:
        text = normalize(f"{ticket.subject} {ticket.body}")
        scores: Dict[str, float] = {}
        evidence: Dict[str, List[str]] = {}
        tokens = set(tokenize(text))

        for key, definition in CATEGORIES.items():
            hits = contains_any(text, definition.keywords)
            token_hits = [kw for kw in definition.keywords if kw in tokens]
            score = len(hits) * 2.0 + len(token_hits) * 1.0
            if key == "bug_outage" and any(code in text for code in ["500", "503", "timeout"]):
                score += 2.0
            scores[key] = score
            evidence[key] = hits[:5]

        best_key = max(scores, key=scores.get)
        total = sum(scores.values())
        if scores[best_key] <= 0:
            best_key = "how_to"
            confidence = 0.42
            ev = ["No strong category keywords found; defaulted to general support."]
        else:
            confidence = clamp(0.40 + scores[best_key] / max(total, 1.0) * 0.60)
            ev = evidence[best_key] or ["Matched category-level semantic keywords."]

        trace = AgentTrace(
            agent="IntentAgent",
            decision=best_key,
            confidence=round(confidence, 2),
            evidence=ev,
        )
        return best_key, confidence, trace


class UrgencyAgent:
    def score(self, ticket: TicketInput, category: str) -> Tuple[Priority, str, bool, float, AgentTrace]:
        text = normalize(f"{ticket.subject} {ticket.body}")
        hits = contains_any(text, URGENCY_TERMS)
        low_hits = contains_any(text, LOW_URGENCY_TERMS)

        score = 20 + len(hits) * 14 - len(low_hits) * 8
        if ticket.customer_tier == "enterprise":
            score += 18
        elif ticket.customer_tier == "pro":
            score += 10
        if category == "security_privacy":
            score += 22
        if category == "bug_outage":
            score += 16
        if "all users" in text or "security breach" in text or "data loss" in text:
            score += 22
        score = max(0, min(100, score))

        if score >= 85:
            priority: Priority = "P0"
            sla = "15 minutes"
        elif score >= 65:
            priority = "P1"
            sla = "1 hour"
        elif score >= 40:
            priority = "P2"
            sla = "4 business hours"
        else:
            priority = "P3"
            sla = "2 business days"

        escalation_required = priority in {"P0", "P1"} or category == "security_privacy"
        confidence = clamp(0.50 + abs(score - 50) / 100)
        evidence = hits[:6]
        if ticket.customer_tier in {"enterprise", "pro"}:
            evidence.append(f"customer_tier={ticket.customer_tier}")
        if category in {"bug_outage", "security_privacy"}:
            evidence.append(f"category={category}")
        if not evidence:
            evidence.append("No high-urgency signal detected.")

        return priority, sla, escalation_required, confidence, AgentTrace(
            agent="UrgencyAgent",
            decision=f"{priority}, sla={sla}, escalation={escalation_required}",
            confidence=round(confidence, 2),
            evidence=evidence,
        )


class SentimentAgent:
    def analyze(self, ticket: TicketInput) -> Tuple[Sentiment, float, AgentTrace]:
        text = normalize(f"{ticket.subject} {ticket.body}")
        negative_hits = contains_any(text, NEGATIVE_TERMS)
        positive_hits = contains_any(text, POSITIVE_TERMS)
        raw = len(negative_hits) - len(positive_hits)

        if raw >= 3:
            sentiment: Sentiment = "very_negative"
        elif raw >= 1:
            sentiment = "negative"
        elif raw <= -1:
            sentiment = "positive"
        else:
            sentiment = "neutral"

        confidence = clamp(0.50 + min(abs(raw), 3) * 0.15)
        evidence = negative_hits[:4] + positive_hits[:4]
        if not evidence:
            evidence = ["No strong sentiment signal detected."]
        return sentiment, confidence, AgentTrace(
            agent="SentimentAgent",
            decision=sentiment,
            confidence=round(confidence, 2),
            evidence=evidence,
        )

from pathlib import Path
from typing import List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.agent import CustomerSupportTriageAgent
from app.classifier import CATEGORIES
from app.config import settings
from app.schemas import StoredTicket, TicketInput, TriageResult
from app.storage import TicketStore

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title="Customer Support Triage Agent",
    description="A multi-agent workflow for classifying, routing, and drafting replies for support tickets.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
agent = CustomerSupportTriageAgent(settings.kb_path)
store = TicketStore(settings.database_path)


@app.get("/")
def index():
    return FileResponse(BASE_DIR / "static" / "index.html")


@app.get("/api/health")
def health():
    return {"status": "ok", "environment": settings.app_env}


@app.get("/api/categories")
def categories():
    return {
        key: {"label": value.label, "team": value.team, "keywords_count": len(value.keywords)}
        for key, value in CATEGORIES.items()
    }


@app.post("/api/triage", response_model=TriageResult)
def triage(ticket: TicketInput):
    result = agent.triage(ticket)
    store.save(ticket, result)
    return result


@app.get("/api/tickets", response_model=List[StoredTicket])
def list_tickets(limit: int = 50):
    return store.list_recent(limit=limit)

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field

CustomerTier = Literal["free", "standard", "pro", "enterprise"]
Channel = Literal["email", "chat", "phone", "social", "api", "other"]
Priority = Literal["P0", "P1", "P2", "P3"]
Sentiment = Literal["positive", "neutral", "negative", "very_negative"]


class TicketInput(BaseModel):
    subject: str = Field(..., min_length=3, examples=["Login fails after password reset"])
    body: str = Field(..., min_length=5, examples=["The customer cannot log in after resetting the password."])
    customer_tier: CustomerTier = "standard"
    channel: Channel = "email"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)


class AgentTrace(BaseModel):
    agent: str
    decision: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    evidence: List[str] = Field(default_factory=list)


class KnowledgeArticle(BaseModel):
    id: str
    title: str
    category: str
    score: float
    summary: str


class TriageResult(BaseModel):
    ticket_id: str
    category: str
    priority: Priority
    sentiment: Sentiment
    confidence: float = Field(..., ge=0.0, le=1.0)
    assigned_team: str
    escalation_required: bool
    sla_target: str
    customer_reply_draft: str
    internal_handoff: str
    retrieved_articles: List[KnowledgeArticle] = Field(default_factory=list)
    trace: List[AgentTrace] = Field(default_factory=list)


class StoredTicket(BaseModel):
    id: int
    created_at: str
    input: TicketInput
    result: TriageResult

from pathlib import Path
from statistics import mean
from uuid import uuid4

from app.classifier import IntentAgent, SentimentAgent, UrgencyAgent
from app.composer import ResponseAgent, RoutingAgent
from app.config import settings
from app.kb import KnowledgeAgent
from app.schemas import AgentTrace, TicketInput, TriageResult
from app.text_utils import clamp


class CustomerSupportTriageAgent:
    def __init__(self, kb_path: Path | None = None):
        self.intent_agent = IntentAgent()
        self.urgency_agent = UrgencyAgent()
        self.sentiment_agent = SentimentAgent()
        self.knowledge_agent = KnowledgeAgent(kb_path or settings.kb_path)
        self.routing_agent = RoutingAgent()
        self.response_agent = ResponseAgent()

    def triage(self, ticket: TicketInput) -> TriageResult:
        text = f"{ticket.subject}\n{ticket.body}"
        trace: list[AgentTrace] = []

        category, intent_confidence, intent_trace = self.intent_agent.classify(ticket)
        trace.append(intent_trace)

        priority, sla_target, escalation_required, urgency_confidence, urgency_trace = self.urgency_agent.score(ticket, category)
        trace.append(urgency_trace)

        sentiment, sentiment_confidence, sentiment_trace = self.sentiment_agent.analyze(ticket)
        trace.append(sentiment_trace)

        articles = self.knowledge_agent.search(text, category=category, top_k=3)
        retrieval_confidence = articles[0].score if articles else 0.35
        trace.append(AgentTrace(
            agent="KnowledgeAgent",
            decision=f"Retrieved {len(articles)} articles.",
            confidence=round(retrieval_confidence, 2),
            evidence=[a.title for a in articles] or ["No close knowledge-base match found."],
        ))

        assigned_team, routing_trace = self.routing_agent.route(category, priority, escalation_required)
        trace.append(routing_trace)

        customer_reply, internal_handoff, response_trace = self.response_agent.compose(
            ticket=ticket,
            category=category,
            priority=priority,
            sentiment=sentiment,
            assigned_team=assigned_team,
            escalation_required=escalation_required,
            sla_target=sla_target,
            articles=articles,
        )
        trace.append(response_trace)

        final_confidence = clamp(mean([
            intent_confidence,
            urgency_confidence,
            sentiment_confidence,
            retrieval_confidence,
            routing_trace.confidence,
            response_trace.confidence,
        ]))
        trace.append(AgentTrace(
            agent="SupervisorAgent",
            decision="Approved triage package for operator review.",
            confidence=round(final_confidence, 2),
            evidence=["All agent outputs normalized into the TriageResult schema."],
        ))

        return TriageResult(
            ticket_id=f"ticket_{uuid4().hex[:12]}",
            category=category,
            priority=priority,
            sentiment=sentiment,
            confidence=round(final_confidence, 2),
            assigned_team=assigned_team,
            escalation_required=escalation_required,
            sla_target=sla_target,
            customer_reply_draft=customer_reply,
            internal_handoff=internal_handoff,
            retrieved_articles=articles,
            trace=trace,
        )

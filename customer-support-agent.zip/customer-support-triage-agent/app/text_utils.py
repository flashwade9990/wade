import re
from typing import Iterable, List

_WORD_RE = re.compile(r"[a-z0-9_]+|[\u4e00-\u9fff]", re.IGNORECASE)


def normalize(text: str) -> str:
    return " ".join(text.lower().strip().split())


def tokenize(text: str) -> List[str]:
    return _WORD_RE.findall(normalize(text))


def contains_any(text: str, phrases: Iterable[str]) -> List[str]:
    haystack = normalize(text)
    hits = []
    for phrase in phrases:
        p = phrase.lower().strip()
        if p and p in haystack:
            hits.append(phrase)
    return hits


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))

import json
from pathlib import Path
from typing import Dict, List

from app.schemas import KnowledgeArticle
from app.text_utils import normalize, tokenize


class KnowledgeAgent:
    def __init__(self, kb_path: Path):
        self.kb_path = kb_path
        self.articles = self._load_articles(kb_path)

    def _load_articles(self, path: Path) -> List[Dict]:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("articles", [])

    def search(self, query: str, category: str, top_k: int = 3) -> List[KnowledgeArticle]:
        query_tokens = set(tokenize(query))
        results = []

        for article in self.articles:
            article_text = normalize(" ".join([
                article.get("title", ""),
                article.get("summary", ""),
                " ".join(article.get("tags", [])),
                article.get("category", ""),
            ]))
            article_tokens = set(tokenize(article_text))
            overlap = len(query_tokens.intersection(article_tokens))
            category_boost = 4 if article.get("category") == category else 0
            tag_boost = sum(1 for tag in article.get("tags", []) if normalize(tag) in normalize(query))
            score = overlap + category_boost + tag_boost * 2
            if score <= 0:
                continue
            results.append((score, article))

        results.sort(key=lambda x: x[0], reverse=True)
        normalized = []
        max_score = results[0][0] if results else 1
        for score, article in results[:top_k]:
            normalized.append(KnowledgeArticle(
                id=article["id"],
                title=article["title"],
                category=article["category"],
                score=round(score / max_score, 2),
                summary=article["summary"],
            ))
        return normalized

import json
import sqlite3
from pathlib import Path
from typing import List

from app.schemas import StoredTicket, TicketInput, TriageResult


CREATE_SQL = """
CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    input_json TEXT NOT NULL,
    result_json TEXT NOT NULL
)
"""


class TicketStore:
    def __init__(self, database_path: Path):
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.init_db()

    def connect(self):
        return sqlite3.connect(self.database_path)

    def init_db(self) -> None:
        with self.connect() as conn:
            conn.execute(CREATE_SQL)
            conn.commit()

    def save(self, ticket: TicketInput, result: TriageResult) -> int:
        with self.connect() as conn:
            cursor = conn.execute(
                "INSERT INTO tickets (input_json, result_json) VALUES (?, ?)",
                (ticket.model_dump_json(), result.model_dump_json()),
            )
            conn.commit()
            return int(cursor.lastrowid)

    def list_recent(self, limit: int = 50) -> List[StoredTicket]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT id, created_at, input_json, result_json FROM tickets ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            StoredTicket(
                id=row[0],
                created_at=row[1],
                input=TicketInput(**json.loads(row[2])),
                result=TriageResult(**json.loads(row[3])),
            )
            for row in rows
        ]

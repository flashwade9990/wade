from typing import List, Tuple

from app.classifier import CATEGORIES
from app.schemas import AgentTrace, KnowledgeArticle, Priority, Sentiment, TicketInput


class RoutingAgent:
    def route(self, category: str, priority: Priority, escalation_required: bool) -> Tuple[str, AgentTrace]:
        team = CATEGORIES.get(category, CATEGORIES["how_to"]).team
        if priority == "P0" and category != "security_privacy":
            team = "Engineering Incident Commander"
        elif category == "security_privacy":
            team = "Security Response"
        trace = AgentTrace(
            agent="RoutingAgent",
            decision=team,
            confidence=0.86,
            evidence=[f"category={category}", f"priority={priority}", f"escalation={escalation_required}"],
        )
        return team, trace


class ResponseAgent:
    def compose(
        self,
        ticket: TicketInput,
        category: str,
        priority: Priority,
        sentiment: Sentiment,
        assigned_team: str,
        escalation_required: bool,
        sla_target: str,
        articles: List[KnowledgeArticle],
    ) -> Tuple[str, str, AgentTrace]:
        category_label = CATEGORIES.get(category, CATEGORIES["how_to"]).label
        article_titles = [a.title for a in articles]
        article_block = "\n".join(f"- {a.title}: {a.summary}" for a in articles) or "- No high-confidence KB article found."

        if escalation_required:
            opening = "Thanks for flagging this. We understand this may be urgent and we have escalated it to the right team."
        elif sentiment in {"negative", "very_negative"}:
            opening = "Thanks for reaching out. We are sorry for the frustration here and will help you get this resolved."
        else:
            opening = "Thanks for reaching out. We can help with this."

        customer_reply = (
            f"Hi,\n\n"
            f"{opening}\n\n"
            f"We classified your request as: {category_label}. "
            f"The current priority is {priority}, with an expected first-response target of {sla_target}.\n\n"
            f"Suggested next step: please share any screenshots, timestamps, affected account IDs, or request IDs that may help us verify the issue.\n\n"
        )
        if article_titles:
            customer_reply += "Potentially relevant help articles:\n" + "\n".join(f"- {title}" for title in article_titles) + "\n\n"
        customer_reply += "We will follow up as soon as we have the next update.\n"

        internal_handoff = (
            f"Ticket subject: {ticket.subject}\n"
            f"Category: {category} ({category_label})\n"
            f"Priority: {priority}\n"
            f"Sentiment: {sentiment}\n"
            f"Assigned team: {assigned_team}\n"
            f"Escalation required: {escalation_required}\n"
            f"SLA target: {sla_target}\n\n"
            f"Customer message:\n{ticket.body}\n\n"
            f"Relevant KB context:\n{article_block}\n\n"
            f"Recommended operator action:\n{self._recommended_action(category, priority)}"
        )

        trace = AgentTrace(
            agent="ResponseAgent",
            decision="Generated customer reply draft and internal handoff.",
            confidence=0.78 if articles else 0.62,
            evidence=article_titles or ["Template generated without retrieved article."],
        )
        return customer_reply, internal_handoff, trace

    def _recommended_action(self, category: str, priority: Priority) -> str:
        if priority in {"P0", "P1"}:
            return "Acknowledge immediately, create incident or escalation record, and post updates on a fixed cadence."
        if category == "billing_refund":
            return "Verify account, invoice ID, charge timestamp, and refund eligibility before replying."
        if category == "login_access":
            return "Check identity provider status, recent password reset events, and MFA enrollment state."
        if category == "integration_api":
            return "Ask for request ID, endpoint, timestamp, payload sample, and response code."
        if category == "feature_request":
            return "Capture the user problem, expected workflow, business impact, and affected segment."
        return "Confirm reproduction details, answer with the most relevant KB article, and ask one clarifying question if confidence is low."

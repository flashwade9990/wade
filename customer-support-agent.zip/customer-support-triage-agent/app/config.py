import os
from pathlib import Path
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    app_env: str = os.getenv("APP_ENV", "local")
    database_path: Path = Path(os.getenv("DATABASE_PATH", "data/tickets.sqlite3"))
    kb_path: Path = Path(os.getenv("KB_PATH", "app/sample_data/kb.json"))


settings = Settings()
